>>This reciepe id divided in 2 parts one is the torte and other is custard.

INGREDIENTS FOR TORTE:

>> 6 Coles Australian Free Range Egg whites
>> 300g caster sugar
>> 1 1/3 cups (135g) hazelnut meal
>> 1 tsp white vinegar
>> 250g strawberries, halved
>> 125g fresh or frozen blackberries
>> 125g fresh or frozen raspberries

....................................................................................

INGREDIENTS FOR CUSTARD:

>> 300ml thickened cream
>> 300ml full-cream milk
>> 6 Coles Australian Free Range Egg yolks
>> 100g caster sugar
>> 2 tbs cocoa powder
>> 1 tbs cornflour
>> Pinch of salt
>> 100g 70% cocoa dark chocolate, chopped
>> 1 tsp vanilla extract