METHOD:

Step 1:
Preheat oven to 130°C fan-forced. Line 2-3 baking trays with baking paper. Draw three 20cm circles on the paper and turn paper over.

....................................................................................

Step 2:
Use an electric mixer to whisk the egg whites in a clean, dry bowl until medium peaks form. Add the sugar, 1 heaped dessertspoonful at a time, beating well after each addition, until the mixture is very stiff and glossy. Gently fold in the hazelnut meal and vinegar until almost combined.

....................................................................................

Step 3:
Using the circles as a guide, spread the mixture in three even discs on the prepared trays. Bake for 1 hour. Turn oven off. Leave meringue discs in the closed oven to cool completely.

....................................................................................

Step 4:
Meanwhile, to make the chocolate custard, combine the cream and milk in a large microwave-safe bowl. Heat in microwave on high for 3-4 mins.

....................................................................................

Step 5:
While the milk mixture is heating, whisk the egg yolks and sugar in a bowl until well combined. Whisk in the cocoa powder, cornflour and salt until smooth.

....................................................................................

Step 6:
Add the egg mixture to the hot milk mixture and whisk well to combine. Heat in microwave, whisking every 2 mins, until the custard thickens. Add the chocolate and vanilla and whisk until smooth. Use a spatula to scrape down the side of the bowl, then cover the surface of the custard with plastic wrap and set aside to cool completely.

....................................................................................

Step 7:
Place 1 meringue disc on a serving plate. Spread with one-third of the chocolate custard. Top with one-third of the berries. Continue layering with remaining meringue discs, chocolate custard and berries. Serve immediately.

....................................................................................

YOUR CHOC-HAZELNUT AND BERRY MERINGUE TORTE IS READY :)